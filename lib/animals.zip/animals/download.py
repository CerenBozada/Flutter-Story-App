import os
import json
a = '''[
  {
    "id": 1,
    "name": "Kedi",
    "image":
        "https://pbs.twimg.com/profile_images/378800000623628092/e6b938f45540707f33470be028e292d1_400x400.jpeghttps://upload.wikimedia.org/wikipedia/commons/thumb/6/66/An_up-close_picture_of_a_curious_male_domestic_shorthair_tabby_cat.jpg/1200px-An_up-close_picture_of_a_curious_male_domestic_shorthair_tabby_cat.jpg",
    "sound": "assets/sounds/animals/kedi.mp3"
  },
  {
    "id": 2,
    "name": "Köpek",
    "image":
        "https://pbs.twimg.com/profile_images/1573605286/dalmayal_400x400.jpg",
    "sound": "assets/sounds/animals/kopek.mp3"
  },
  {
    "id": 3,
    "name": "Tavşan",
    "image":
        "https://pbs.twimg.com/profile_images/627865463763128320/NvPIrkhu_400x400.jpg",
    "sound": "assets/sounds/animals/tavsan.mp3"
  },
  {
    "id": 4,
    "name": "At",
    "image":
        "https://pbs.twimg.com/profile_images/886336222326476800/P8z-11PM_400x400.jpg",
    "sound":"assets/sounds/animals/at.mp3"
  },
  {
    "id": 5,
    "name": "Fil",
    "image":
        "https://pbs.twimg.com/profile_images/461179605273935873/H9x9SEQf_400x400.jpeg",
    "sound": "assets/sounds/animals/fil.mp3"
  },
  {
    "id": 6,
    "name": "Zürafa",
    "image":
        "https://im0-tub-tr.yandex.net/i?id=4f4a489342342a152d5d2ad1189159bf&n=13&exp=1",
    "sound" : "assets/sounds/animals/zurafa.mp3"
  },
  {
    "id": 7,
    "name": "Kuş",
    "image": "https://animaloilmaker.com/images/average-violet-opaline-8.jpg",
    "sound": "assets/sounds/animals/kus.mp3"
  },
  {
    "id": 8,
    "name": "Balık",
    "image":
        "https://avatars.mds.yandex.net/get-pdb/2800487/cab29aab-3a01-4d55-b326-1738bc929c36/s1200?webp=false",
    "sound": "assets/sounds/animals/balik.mp3"
  },
  {
    "id": 9,
    "name": "Aslan",
    "image":
        "https://pbs.twimg.com/profile_images/1110433124645662721/_z0dldIP_400x400.png",
    "sound": "assets/sounds/animals/aslan.mp3"
  },
  {
    "id": 10,
    "name": "Panda",
    "image":
        "https://pbs.twimg.com/profile_images/1159084599051542529/-9Cri5Bp_400x400.jpg",
    "sound": "assets/sounds/animals/panda.mp3"
  },
  {
    "id": 11,
    "name": "Rakun",
    "image":
        "https://pbs.twimg.com/profile_images/581574562548154368/Z-biYIjw_400x400.jpg",
    "sound": "assets/sounds/animals/rakun.mp3"
  },
  {
    "id": 12,
    "name": "Sincap",
    "image":
        "https://yt3.ggpht.com/a/AGF-l79AuCIWxP28sin73FFN0Zb25FcWCdsluJxjmw=s400-mo-c-c0xffffffff-rj-k-no",
    "sound": "assets/sounds/animals/sincap.mp3"
  },
  {
    "id": 13,
    "name": "Yunus",
    "image":
        "https://pbs.twimg.com/profile_images/619044929348632576/lBeC8Amb_400x400.jpg",
    "sound": "assets/sounds/animals/yunus.mp3"
  },
  {
    "id": 14,
    "name": "Ördek",
    "image":
        "https://pbs.twimg.com/profile_images/966648730467340293/lxO98bYv_400x400.jpg",
    "sound": "assets/sounds/animals/ordek.mp3"
  },
  {
    "id": 15,
    "name": "İnek",
    "image":
        "https://pbs.twimg.com/profile_images/834393310903095296/mVzkTzz8_400x400.jpg",
    "sound": "assets/sounds/animals/inek.mp3"
  },
  {
    "id": 16,
    "name": "Maymun",
    "image":
        "https://pbs.twimg.com/profile_images/1175405224690946049/HVZ9DJfX.jpg",
     "sound": "assets/sounds/animals/maymun.mp3"
  },
  {
    "id": 17,
    "name": "Ayı",
    "image":
        "https://static3.stcont.com/datas/photos/800x800/eb/3c/82abfd8b7a0c8966f638d5ea0bf8.jpg?0",
     "sound": "assets/sounds/animals/ayi.mp3"
  },
  {
    "id": 18,
    "name": "Fare",
    "image":
        "https://static.memrise.com/img/400sqf/from/uploads/course_photos/5633609000170824112706.png",
    "sound": "assets/sounds/animals/fare.mp3"
  },
  {
    "id": 19,
    "name": "Su Samuru",
    "image":
        "https://pbs.twimg.com/profile_images/760958184710430720/91WSFaRp.jpg",
    "sound": "assets/sounds/animals/susamuru.mp3"
  },
  {
    "id": 20,
    "name": "Çita",
    "image":
        "https://pbs.twimg.com/profile_images/412187591417417728/jwv3RFtd_400x400.jpeg",
    "sound":  "assets/sounds/animals/cita.mp3"
  },
  {
    "id": 21,
    "name": "Leopar",
    "image":
        "https://pbs.twimg.com/profile_images/1116426080649302017/JU3ZZKK9_400x400.jpg",
    "sound": "assets/sounds/animals/leopar.mp3"
  },
  {
    "id": 22,
    "name": "Koç",
    "image":
        "https://pbs.twimg.com/profile_images/1176391466773557248/eAIyYKuS_400x400.jpg",
    "sound":  "assets/sounds/animals/koc.mp3"
  },
  {
    "id": 23,
    "name": "Yılan",
    "image":
        "https://pbs.twimg.com/profile_images/1145371395809062913/vEpHVw0B_400x400.jpg",
    "sound":  "assets/sounds/animals/yilan.mp3"
  },
  {
    "id": 24,
    "name": "Domuz",
    "image":
        "https://pbs.twimg.com/profile_images/1016278572661555200/XONHR8Qm_400x400.jpg",
    "sound":"assets/sounds/animals/domuz.mp3"
  },
  {
    "id": 25,
    "name": "Kelebek",
    "image":
        "https://pbs.twimg.com/profile_images/537999483959660544/OYRSWcV5_400x400.jpeg",
    "sound": "assets/sounds/animals/kelebek.mp3"
  },
  {
    "id": 26,
    "name": "Kaplumbağa",
    "image":
        "https://pbs.twimg.com/profile_images/715118175667490816/ecIpeFyV_400x400.jpg",
    "sound": "assets/sounds/animals/kaplumbaga.mp3"
  },
  {
    "id": 27,
    "name": "Baykuş",
    "image":
        "https://pbs.twimg.com/profile_images/1139198076738973696/hESP4RWx_400x400.jpg",
    "sound": "assets/sounds/animals/baykus.mp3"
  },
  {
    "id": 28,
    "name": "Tavuk",
    "image":
        "https://im0-tub-tr.yandex.net/i?id=2f49f4925ecdad11ae54767e4815cab4&n=13&exp=1",
    "sound": "assets/sounds/animals/tavuk.mp3"
  },
  {
    "id": 29,
    "name": "Devekuşu",
    "image":
        "https://pbs.twimg.com/profile_images/378800000265366619/9eda3ce7f47ec1de724237c60b3ffd78_400x400.jpeg",
    "sound": "assets/sounds/animals/devekusu.mp3"
  },
  {
    "id": 30,
    "name": "Timsah",
    "image":
        "https://cdn.routefifty.com/media/img/upload/2015/07/30/alligator/open-graph.jpeg",
    "sound":"assets/sounds/animals/timsah.mp3"
  },
  {
    "id": 31,
    "name": "Kanguru",
    "image":
        "https://globustur.spb.ru/cache/images/1a67c215a99636428bf30f5a7ca26faf.jpg",
    "sound":  "assets/sounds/animals/kanguru.mp3"
  },
  {
    "id": 32,
    "name": "Kurbağa",
    "image":
        "https://pbs.twimg.com/profile_images/1162343650355007488/MaHzCnMU.jpg",
    "sound": "assets/sounds/animals/kurbaga.mp3"
  },
  {
    "id": 33,
    "name": "Geyik",
    "image":
        "https://n1outdoors.com/wp-content/uploads/2018/08/buck-at-attention-e1535135916857.jpg",
    "sound": "assets/sounds/animals/geyik.mp3"
  }
]'''
jsonarray = json.loads(a)
for animal in jsonarray:
    os.system("aria2c "+ animal["image"])
    print(animal["image"])